NONNANEST MEDIA KIT
===================
SightAware(tm) by Nonnanest | contactless infrared baby wellness monitor

CONTENTS
--------
photos/
  nonnanest-baby-monitor-camera-parent-unit.png  — Full system hero shot
  Nonnanest_Handheld_table.png                   — Parent display in use (lifestyle)
  Nonnanest_closeup_handheld.png                 — Display close-up (skin temp reading visible)
  Nonnanest_Crib_Arm.png                         — Camera unit, crib arm mount
  Nonnanest_Wall_Mounted.png                     — Camera unit, wall mounted
  Nonnanest_in_the_box.png                       — Full contents / what's in the box

headshots/
  nathan-overbey-headshot.jpg   — Professional headshot, high resolution
  nathan-overbey-family.jpg     — Founder & family, lifestyle

logos/
  nonnanest-logo.png            — Nonnanest logo (round, teal)
  Note: Additional logo formats available on request — hello@nonnanest.com

nonnanest-press-fact-sheet.pdf  — One-page press reference (specs, bio, quotes, contact)

BRAND USAGE
-----------
Please use "Nonnanest" (one word, capital N).
Product name: "SightAware(tm) by Nonnanest"

MEDIA CONTACT
-------------
Nathan Overbey, Founder & CEO
hello@nonnanest.com
nonnanest.com/press

REGULATORY
----------
Nonnanest is a wellness device, not a medical device, and is not intended
to diagnose, treat, cure, or prevent any disease or condition.

(c) 2026 Nonnanest, Inc. Charleston, SC. All rights reserved.
