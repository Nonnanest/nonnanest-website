NONNANEST LOGO PACK
===================

stacked/      Icon above the wordmark. Primary logo.
horizontal/   Icon beside the wordmark. Use in tight, wide spaces.
icon/         The house icon alone. Use where "Nonnanest" appears nearby
              or the space is square (avatars, app-style tiles).

Each logo comes in four colorways, as SVG (vector, preferred) and
PNG (2048px, transparent background):

  FullColor       On white or light backgrounds. Preferred.
  DeepSage        Single-color version.
  Black           Only when color isn't available.
  ReversedWhite   White artwork for dark backgrounds or photos.

USAGE
-----
- Use the supplied artwork. Don't retype the wordmark, recolor parts
  of the logo, or add outlines, shadows or effects.
- Keep clear space around the logo at least as wide as the small
  circle inside the icon.
- Minimum digital sizes: icon 32px, stacked 90px, horizontal 120px wide.
- Full guidelines: Nonnanest_Brand_Standards_v1.0.pdf

Please write the company name as "Nonnanest" (one word, capital N).
The product is "SightAware(tm) by Nonnanest."

Questions or other formats: hello@nonnanest.com
